# [Filter](https://www.w3schools.com/cssref/css3_pr_filter.asp)

filter: none | blur() | brightness() | contrast() | drop-shadow() | grayscale() | hue-rotate() | invert() | opacity() | saturate() | sepia() | url();
