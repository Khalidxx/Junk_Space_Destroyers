# [moment pipe](https://medium.com/@ThulzMtetwa/using-moment-js-as-a-pipe-angular-or-ionic-b0a409f4fc04)
