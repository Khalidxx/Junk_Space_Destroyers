# Lazy Loading

## [page](https://blog.ionicframework.com/ionic-and-lazy-loading-pt-1/)
