# ion-menu

- The menu element should be a sibling to the app's content element
- There can be any number of menus attached to the content
- These can be controlled from the templates, or programmatically using the `MenuController`.

## Menu Types

`overlay`, `reveal` and `push`
