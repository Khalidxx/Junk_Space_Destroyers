# Map

## api key

**AIzaSyCrLo2r2ajGYL_47KIlJJR2OxRlp-bVc0s**

```bash
$ yarn add @ionic-native/google-maps

$ ionic cordova plugin add cordova-plugin-googlemaps \
--variable API_KEY_FOR_ANDROID="AIzaSyCrLo2r2ajGYL_47KIlJJR2OxRlp-bVc0s" \
--variable API_KEY_FOR_IOS="AIzaSyCrLo2r2ajGYL_47KIlJJR2OxRlp-bVc0s"
```

## [prevent tabs show in map page](https://github.com/ionic-team/ionic/issues/10533)
