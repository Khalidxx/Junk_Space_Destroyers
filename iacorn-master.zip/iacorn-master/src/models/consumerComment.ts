export interface ConsumerComment {
  consumerIconLink: string;
  consumerAccountNumber: string;
  date: number;
  rate: number;
  content: string;
  merchantReply: string;
  imageLink: string;
}
