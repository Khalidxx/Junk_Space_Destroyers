export interface HomeBanner {
  title: string;
  content: string;
  imgAddress: string;
}
