export { DatePipe } from "./date/date";
export { MomentPipe } from "./moment/moment";
