// import { observable, action, computed } from "mobx-angular";
import { Injectable } from "@angular/core";
// import { Cuisine } from "../models";

@Injectable()
export class OrderStore {}
